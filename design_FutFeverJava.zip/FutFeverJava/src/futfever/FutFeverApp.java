package futfever;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.*;

public class FutFeverApp extends JFrame {
    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private final Color GREEN = new Color(0,110,79);
    private final Color DARK = new Color(0,47,37);
    private final Color LIGHT = new Color(245,247,246);
    private final Color LINE = new Color(232,236,234);
    private final Color MUTED = new Color(107,114,128);

    public FutFeverApp() {
        setTitle("FutFever - Java");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1180, 760);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(960, 650));
        root.add(indexPanel(), "index");
        root.add(userShell(), "user");
        root.add(adminShell(), "admin");
        setContentPane(root);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch(Exception ignored) {}
            new FutFeverApp().setVisible(true);
        });
    }

    private JPanel indexPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(LIGHT);
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("FUTFEVER", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 46));
        title.setForeground(GREEN);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = new JLabel("Escolha a área da aplicação", SwingConstants.CENTER);
        sub.setForeground(MUTED);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        JPanel grid = new JPanel(new GridLayout(1,2,22,22));
        grid.setOpaque(false);
        grid.setBorder(new EmptyBorder(35,0,0,0));
        grid.add(choiceCard("👤", "Área Utilizador", "Consultar jogos, equipas, bilhetes e perfil", () -> cards.show(root,"user")));
        grid.add(choiceCard("🛡️", "Backoffice Admin", "Gestão completa da competição", () -> cards.show(root,"admin")));
        box.add(title); box.add(sub); box.add(grid);
        p.add(box);
        return p;
    }

    private JPanel choiceCard(String icon, String title, String text, Runnable action) {
        JPanel c = card(); c.setPreferredSize(new Dimension(360,230)); c.setLayout(new BorderLayout(10,10));
        JLabel i = new JLabel(icon); i.setFont(new Font("SansSerif", Font.PLAIN, 52));
        JLabel t = label(title, 25, Font.BOLD, GREEN);
        JTextArea desc = text(text, 15); desc.setForeground(MUTED);
        JButton b = button("Entrar"); b.addActionListener(e -> action.run());
        JPanel top = new JPanel(); top.setOpaque(false); top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.add(i); top.add(t); top.add(desc);
        c.add(top, BorderLayout.CENTER); c.add(b, BorderLayout.SOUTH);
        return c;
    }

    private JPanel userShell() {
        JPanel outer = new JPanel(new GridBagLayout()); outer.setBackground(new Color(230,235,233));
        JPanel phone = new JPanel(new BorderLayout()); phone.setBackground(Color.WHITE);
        phone.setPreferredSize(new Dimension(430, 700)); phone.setBorder(new LineBorder(LINE));
        CardLayout userCards = new CardLayout(); JPanel content = new JPanel(userCards); content.setBackground(Color.WHITE);
        content.add(userHome(userCards, content), "home");
        content.add(simpleListScreen("Jogos", "⚽", new String[]{"Portugal  vs  Brasil | 25 Jun 20:30", "Argentina vs França | 26 Jun 18:00", "Espanha vs Itália | 27 Jun 21:00"}), "jogos");
        content.add(simpleListScreen("Equipas", "👕", new String[]{"🇵🇹 Portugal - Grupo A", "🇧🇷 Brasil - Grupo A", "🇦🇷 Argentina - Grupo B", "🇫🇷 França - Grupo B"}), "equipas");
        content.add(simpleListScreen("Bilhetes", "🎟️", new String[]{"Portugal x Brasil - 75€", "Argentina x França - 90€", "Espanha x Itália - 65€"}), "bilhetes");
        content.add(profileScreen(), "perfil");
        phone.add(content, BorderLayout.CENTER);
        phone.add(bottomNav(userCards, content), BorderLayout.SOUTH);
        outer.add(phone);
        return outer;
    }

    private JPanel userHome(CardLayout userCards, JPanel content) {
        JPanel p = new JPanel(); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(22,22,10,22));
        JPanel header = new JPanel(new BorderLayout()); header.setOpaque(false);
        JPanel htext = new JPanel(); htext.setOpaque(false); htext.setLayout(new BoxLayout(htext,BoxLayout.Y_AXIS));
        htext.add(label("Olá, João!", 20, Font.BOLD, Color.BLACK)); htext.add(label("Bem-vindo ao FutFever", 13, Font.PLAIN, MUTED));
        JButton admin = smallButton("🛡️ ADMIN"); admin.addActionListener(e -> cards.show(root,"admin"));
        header.add(htext, BorderLayout.WEST); header.add(admin, BorderLayout.EAST);
        JPanel hero = gradientPanel(); hero.setLayout(new BorderLayout()); hero.setBorder(new EmptyBorder(20,20,20,20));
        JPanel heroText = new JPanel(); heroText.setOpaque(false); heroText.setLayout(new BoxLayout(heroText, BoxLayout.Y_AXIS));
        heroText.add(label("VIVE A EMOÇÃO", 20, Font.BOLD, Color.WHITE)); heroText.add(label("DO FUTEBOL", 20, Font.BOLD, Color.WHITE));
        JLabel hp = label("Consulta jogos, equipas e bilhetes.", 13, Font.PLAIN, Color.WHITE); heroText.add(hp);
        JButton verJogos = whiteButton("Ver Jogos"); verJogos.addActionListener(e -> userCards.show(content,"jogos")); heroText.add(Box.createVerticalStrut(10)); heroText.add(verJogos);
        JLabel ball = new JLabel("⚽"); ball.setFont(new Font("SansSerif", Font.PLAIN, 70));
        hero.add(heroText, BorderLayout.WEST); hero.add(ball, BorderLayout.EAST);
        JPanel quick = new JPanel(new GridLayout(2,3,12,12)); quick.setOpaque(false); quick.setBorder(new EmptyBorder(18,0,18,0));
        addQuick(quick,"⚽","Jogos", userCards, content, "jogos"); addQuick(quick,"👕","Equipas", userCards, content, "equipas"); addQuick(quick,"🎟️","Bilhetes", userCards, content, "bilhetes");
        addQuick(quick,"📅","Calendário", userCards, content, "jogos"); addQuick(quick,"🏟️","Estádios", userCards, content, "jogos"); addQuick(quick,"🪪","ID Digital", userCards, content, "perfil");
        p.add(header); p.add(Box.createVerticalStrut(12)); p.add(hero); p.add(quick); p.add(sectionTitle("Próximos jogos"));
        p.add(matchCard("Grupo A · Jornada 1", "Portugal", "20:30\n25 Jun", "Brasil", "Estádio de Lusail · Bilhetes disponíveis"));
        p.add(matchCard("Grupo B · Jornada 1", "Argentina", "18:00\n26 Jun", "França", "Estádio Al Bayt · Últimos lugares"));
        return p;
    }

    private JPanel adminShell() {
        JPanel layout = new JPanel(new BorderLayout()); layout.setBackground(LIGHT);
        JPanel sidebar = new JPanel(); sidebar.setPreferredSize(new Dimension(250,0)); sidebar.setBackground(DARK); sidebar.setBorder(new EmptyBorder(24,18,24,18)); sidebar.setLayout(new BoxLayout(sidebar,BoxLayout.Y_AXIS));
        JLabel brand = label("⚽ FUTFEVER", 23, Font.BOLD, Color.WHITE); sidebar.add(brand); sidebar.add(label("ADMIN", 10, Font.BOLD, new Color(215,242,231))); sidebar.add(Box.createVerticalStrut(20));
        CardLayout adminCards = new CardLayout(); JPanel main = new JPanel(adminCards);
        String[] pages = {"Dashboard","Calendário","Jogos","Equipas","Árbitros","Estádios","Grupos","Bilhetes","Utilizadores","Relatórios"};
        for(String page: pages) {
            JButton nav = navButton(iconFor(page)+"  "+page); nav.addActionListener(e -> adminCards.show(main, page)); sidebar.add(nav);
        }
        JButton sair = navButton("🚪  Sair"); sair.addActionListener(e -> cards.show(root,"index")); sidebar.add(Box.createVerticalGlue()); sidebar.add(sair);
        main.add(adminDashboard(), "Dashboard");
        for(String page: Arrays.copyOfRange(pages,1,pages.length)) main.add(adminTablePage(page), page);
        layout.add(sidebar, BorderLayout.WEST); layout.add(main, BorderLayout.CENTER); return layout;
    }

    private JComponent adminDashboard() {
        JPanel p = adminBase("Dashboard", "Backoffice - gestão completa da competição");
        JPanel stats = new JPanel(new GridLayout(1,5,18,18)); stats.setOpaque(false);
        stats.add(stat("Jogos","64","📅")); stats.add(stat("Bilhetes","42k","🎟️")); stats.add(stat("Equipas","32","👥")); stats.add(stat("Árbitros","64","⚖️")); stats.add(stat("Receita","€2.1M","💶"));
        p.add(stats); p.add(Box.createVerticalStrut(20));
        JPanel mid = new JPanel(new GridLayout(1,2,18,18)); mid.setOpaque(false);
        JPanel chart = card(); chart.setLayout(new BorderLayout()); chart.add(label("Jogos por Data",18,Font.BOLD,Color.BLACK),BorderLayout.NORTH); chart.add(barChart(),BorderLayout.CENTER);
        JPanel donut = card(); donut.setLayout(new BorderLayout()); donut.add(label("Jogos por Estado",18,Font.BOLD,Color.BLACK),BorderLayout.NORTH); donut.add(new JLabel("   🟢 Agendados    🟡 Em curso    🔴 Terminados", SwingConstants.CENTER),BorderLayout.CENTER);
        mid.add(chart); mid.add(donut); p.add(mid); p.add(Box.createVerticalStrut(20));
        p.add(tableCard("Próximos jogos", new String[]{"Data","Hora","Grupo","Casa","Fora","Estádio","Estado"}, new String[][]{{"25 Jun","20:30","A","Portugal","Brasil","Lusail","Agendado"},{"26 Jun","18:00","B","Argentina","França","Al Bayt","Agendado"},{"27 Jun","21:00","C","Espanha","Itália","Arena Norte","Em curso"}}));
        return new JScrollPane(p);
    }

    private JComponent adminTablePage(String title) {
        JPanel p = adminBase(title, "Gestão de " + title.toLowerCase());
        JPanel form = card(); form.setLayout(new GridLayout(2,3,12,12));
        form.add(input("Nome / título")); form.add(input("Data / país")); form.add(input("Estado")); form.add(input("Observações")); form.add(button("Guardar")); form.add(button("Limpar"));
        p.add(form); p.add(Box.createVerticalStrut(18));
        p.add(tableCard("Lista", new String[]{"Nome","Categoria","Estado","Ações"}, new String[][]{{title+" 1","Principal","Ativo","Editar / Remover"},{title+" 2","Secundário","Pendente","Editar / Remover"},{title+" 3","Principal","Ativo","Editar / Remover"}}));
        return new JScrollPane(p);
    }

    private JPanel adminBase(String title, String subtitle) { JPanel p = new JPanel(); p.setBackground(LIGHT); p.setBorder(new EmptyBorder(28,28,28,28)); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.add(label(title,32,Font.BOLD,Color.BLACK)); p.add(label(subtitle,14,Font.PLAIN,MUTED)); p.add(Box.createVerticalStrut(24)); return p; }

    private JPanel card() { JPanel p = new JPanel(); p.setBackground(Color.WHITE); p.setBorder(new CompoundBorder(new LineBorder(LINE,1,true), new EmptyBorder(18,18,18,18))); return p; }
    private JLabel label(String s,int size,int style,Color c){ JLabel l=new JLabel(s); l.setFont(new Font("SansSerif",style,size)); l.setForeground(c); return l; }
    private JTextArea text(String s,int size){ JTextArea a=new JTextArea(s); a.setFont(new Font("SansSerif",Font.PLAIN,size)); a.setLineWrap(true); a.setWrapStyleWord(true); a.setOpaque(false); a.setEditable(false); return a; }
    private JButton button(String s){ JButton b=new JButton(s); b.setForeground(Color.WHITE); b.setBackground(GREEN); b.setFocusPainted(false); b.setBorder(new EmptyBorder(11,16,11,16)); return b; }
    private JButton whiteButton(String s){ JButton b=button(s); b.setBackground(Color.WHITE); b.setForeground(GREEN); return b; }
    private JButton smallButton(String s){ JButton b=whiteButton(s); b.setBorder(new EmptyBorder(8,10,8,10)); return b; }
    private JButton navButton(String s){ JButton b=new JButton(s); b.setHorizontalAlignment(SwingConstants.LEFT); b.setForeground(new Color(215,242,231)); b.setBackground(DARK); b.setBorder(new EmptyBorder(12,14,12,14)); b.setFocusPainted(false); return b; }
    private JTextField input(String ph){ JTextField f=new JTextField(ph); f.setBorder(new CompoundBorder(new LineBorder(LINE), new EmptyBorder(10,10,10,10))); return f; }
    private JPanel gradientPanel(){ return new JPanel(){ protected void paintComponent(Graphics g){ Graphics2D g2=(Graphics2D)g; g2.setPaint(new GradientPaint(0,0,DARK,getWidth(),getHeight(),GREEN)); g2.fillRoundRect(0,0,getWidth(),getHeight(),18,18); } public boolean isOpaque(){return false;} }; }
    private void addQuick(JPanel q,String icon,String txt,CardLayout cl,JPanel content,String target){ JButton b=whiteButton("<html><center><span style='font-size:20px'>"+icon+"</span><br>"+txt+"</center></html>"); b.setBorder(new CompoundBorder(new LineBorder(LINE,1,true),new EmptyBorder(12,5,12,5))); b.addActionListener(e->cl.show(content,target)); q.add(b); }
    private JLabel sectionTitle(String s){ JLabel l=label(s,20,Font.BOLD,Color.BLACK); l.setBorder(new EmptyBorder(0,0,8,0)); return l; }
    private JPanel matchCard(String group,String home,String time,String away,String stadium){ JPanel c=card(); c.setMaximumSize(new Dimension(390,120)); c.setLayout(new BorderLayout()); c.add(label(group,12,Font.PLAIN,MUTED),BorderLayout.NORTH); JLabel teams=label(home+"     " + time.replace("\n"," ") + "     "+away,16,Font.BOLD,GREEN); c.add(teams,BorderLayout.CENTER); c.add(label(stadium,12,Font.PLAIN,MUTED),BorderLayout.SOUTH); return c; }
    private JPanel simpleListScreen(String title,String icon,String[] rows){ JPanel p=new JPanel(); p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(24,22,10,22)); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.add(label(icon+"  "+title,24,Font.BOLD,GREEN)); p.add(Box.createVerticalStrut(16)); for(String r:rows){ JPanel c=card(); c.setMaximumSize(new Dimension(390,76)); c.setLayout(new BorderLayout()); c.add(label(r,15,Font.BOLD,Color.BLACK),BorderLayout.CENTER); p.add(c); p.add(Box.createVerticalStrut(10)); } return p; }
    private JPanel profileScreen(){ JPanel p=simpleListScreen("Perfil","👤",new String[]{"João Silva", "joao@email.com", "Bilhetes comprados: 3", "Notificações ativas"}); JButton back=button("Voltar ao início"); back.addActionListener(e->cards.show(root,"index")); p.add(back); return p; }
    private JPanel bottomNav(CardLayout cl,JPanel content){ JPanel n=new JPanel(new GridLayout(1,4)); n.setBorder(new MatteBorder(1,0,0,0,LINE)); String[][] items={{"⌂\nInício","home"},{"⚽\nJogos","jogos"},{"🎟️\nBilhetes","bilhetes"},{"👤\nPerfil","perfil"}}; for(String[] it:items){ JButton b=whiteButton("<html><center>"+it[0].replace("\n","<br>")+"</center></html>"); b.addActionListener(e->cl.show(content,it[1])); n.add(b);} return n; }
    private JPanel stat(String name,String value,String icon){ JPanel c=card(); c.setLayout(new BorderLayout()); c.add(label(name,13,Font.PLAIN,MUTED),BorderLayout.NORTH); c.add(label(value,24,Font.BOLD,Color.BLACK),BorderLayout.CENTER); c.add(label(icon,24,Font.PLAIN,GREEN),BorderLayout.EAST); return c; }
    private JPanel barChart(){ return new JPanel(){ protected void paintComponent(Graphics g){ super.paintComponent(g); int[] h={40,80,120,95,170,140}; int w=getWidth()/8; g.setColor(GREEN); for(int i=0;i<h.length;i++) g.fillRoundRect(25+i*(w+25), getHeight()-h[i]-20, w, h[i], 10,10); } }; }
    private JPanel tableCard(String title,String[] cols,String[][] rows){ JPanel c=card(); c.setLayout(new BorderLayout(0,12)); c.add(label(title,18,Font.BOLD,Color.BLACK),BorderLayout.NORTH); JTable t=new JTable(rows,cols); t.setRowHeight(32); t.getTableHeader().setFont(new Font("SansSerif",Font.BOLD,13)); c.add(new JScrollPane(t),BorderLayout.CENTER); return c; }
    private String iconFor(String p){ switch(p){case "Dashboard":return "📊";case "Calendário":return "📅";case "Jogos":return "⚽";case "Equipas":return "👕";case "Árbitros":return "👨‍⚖️";case "Estádios":return "🏟️";case "Grupos":return "🧩";case "Bilhetes":return "🎟️";case "Utilizadores":return "👥";default:return "📈";} }
}
